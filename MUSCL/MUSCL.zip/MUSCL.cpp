#include<iostream>
#include <cmath>
#include<vector>
using namespace std;
double minmod(double a, double b);
void MUSCL(double Q[][3], double F[][3],int N, double cfl, double dt, double dx, double k, double b)
{
	int i, j;
	vector<double> rou(N + 2);
	vector<double> u(N + 2);
	vector<double> p(N + 2);
	vector<double> H(N + 2);
	vector<double> c(N + 2);
	vector<double> rou_a(N + 1);
	vector<double> u_a(N + 1);
	vector<double> p_a(N + 1);
	vector<double> H_a(N + 1);
	vector<double> c_a(N + 1);
	vector<vector<double>> niu(N + 2);
	for (i = 0; i < niu.size(); i++)
		niu[i].resize(3);
	vector<vector<double>> NF(N + 2);
	for (i = 0; i < NF.size(); i++)
		NF[i].resize(3);
	vector<vector<double>> QL(N + 2);
	for (i = 0; i < QL.size(); i++)
		QL[i].resize(3);
	vector<vector<double>> QR(N + 2);
	for (i = 0; i < QR.size(); i++)
		QR[i].resize(3);
	vector<vector<double>> FL(N + 2);
	for (i = 0; i < FL.size(); i++)
		FL[i].resize(3);
	vector<vector<double>> FR(N + 2);
	for (i = 0; i < FR.size(); i++)
		FR[i].resize(3);
	double r = dt / dx;
	double minmod1, minmod2, minmod3, minmod4;
	const double gamma = 1.4;
	for (i = 0; i <= N + 1; i++)
	{
		rou[i] = Q[i][0];
		u[i] = Q[i][1] / Q[i][0];
		p[i] = (gamma - 1) * (Q[i][2] - 0.5 * Q[i][1] * u[i]);
		c[i] = sqrt(gamma * p[i] / rou[i]);
		H[i] = c[i] * c[i] / (gamma - 1) + 0.5 * u[i] * u[i];
	}
	for (i = 1; i <= N; i++)
	{
		rou_a[i] = sqrt(rou[i] * rou[i + 1]);
		u_a[i] = (u[i] * sqrt(rou[i]) + u[i + 1] * sqrt(rou[i + 1])) / (sqrt(rou[i]) + sqrt(rou[i + 1]));
		H_a[i] = (H[i] * sqrt(rou[i]) + H[i + 1] * sqrt(rou[i + 1])) / (sqrt(rou[i]) + sqrt(rou[i + 1]));
		c_a[i] = sqrt((gamma - 1) * (H_a[i] - 0.5 * u_a[i] * u_a[i]));
	}
	for (j = 0; j <= 2; j++)
	{
		for (i = 1; i <= N - 1; i++)
		{
			minmod1 = minmod(Q[i][j] - Q[i - 1][j], b * (Q[i + 1][j] - Q[i][j]));
			minmod2 = minmod(Q[i + 1][j] - Q[i][j], b * (Q[i][j] - Q[i - 1][j]));
			minmod3 = minmod(Q[i + 2][j] - Q[i + 1][j], b * (Q[i + 1][j] - Q[i][j]));
			minmod4 = minmod(Q[i + 1][j] - Q[i][j], b * (Q[i + 2][j] - Q[i + 1][j]));
			QL[i][j] = Q[i][j] + 0.25 * (1 - k) * minmod1 + 0.25 * (1 + k) * minmod2;
			QR[i][j] = Q[i + 1][j] - 0.25 * (1 - k) * minmod3 - 0.25 * (1 + k) * minmod4;
		}
	}
	for (i = 1; i <= N - 1; i++)
	{
		rou[i] = QL[i][0];
		u[i] = QL[i][1] / QL[i][0];
		p[i] = (gamma - 1) * (QL[i][2] - 0.5 * QL[i][1] * u[i]);
	}
	for (i = 1; i <= N - 1; i++)
	{
		FL[i][0] = rou[i] * u[i];
		FL[i][1] = rou[i] * u[i] * u[i] + p[i];
		FL[i][2] = (p[i] / (gamma - 1) + 0.5 * rou[i] * u[i] * u[i] + p[i]) * u[i];
	}
	for (i = 1; i <= N - 1; i++)
	{
		rou[i] = QR[i][0];
		u[i] = QR[i][1] / QR[i][0];
		p[i] = (gamma - 1) * (QR[i][2] - 0.5 * QR[i][1] * u[i]);
	}
	for (i = 1; i <= N - 1; i++)
	{
		FR[i][0] = rou[i] * u[i];
		FR[i][1] = rou[i] * u[i] * u[i] + p[i];
		FR[i][2] = (p[i] / (gamma - 1) + 0.5 * rou[i] * u[i] * u[i] + p[i]) * u[i];
	}
	for (j = 0; j <= 2; j++)
	{
		for (i = 1; i <= N - 1; i++)
			NF[i][j] = 0.5 * (FL[i][j] + FR[i][j]) - 0.5 * u_a[i] * (u_a[i] -c_a[i]) * (u_a[i] + c_a[i]) * (QR[i][j] - QL[i][j]);
	}
	for (j = 0; j <= 2; j++)
	{
		for (i = 2; i <= N-1; i++)
		{
			Q[i][j] = Q[i][j] - r * (NF[i][j] - NF[i-1][j]);
		}
	}
}