#include<cmath>
double Qk(double x)
{
	const double epsilon = 0.125;
	double Qk;
	if (sqrt(x) >= epsilon)
		Qk = sqrt(x);
	else
		Qk = (x * x + epsilon * epsilon) / (2 * epsilon);
	return Qk;
}